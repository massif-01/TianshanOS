#pragma once
/* Internal bounded delivery path. Session mutation and send execute in HTTPD. */
#include "esp_http_server.h"
#include "cJSON.h"
#include <stdbool.h>
#include <stdint.h>
#define TS_WS_TOPIC_TX_SLOTS 32
#define TS_WS_TX_SLOTS (TS_WS_TOPIC_TX_SLOTS + TS_WS_CONNECTIONS)
#define TS_WS_MESSAGE_SLOTS 8
#define TS_WS_FRAME_BYTES 32768
#define TS_WS_LEGACY_BYTES (512 * 1024)
#define TS_WS_TOTAL_BYTES (1024 * 1024)
#ifdef CONFIG_TS_WEBUI_WS_MAX_CLIENTS
#define TS_WS_CONNECTIONS CONFIG_TS_WEBUI_WS_MAX_CLIENTS
#else
#define TS_WS_CONNECTIONS 8
#endif

typedef struct {
    httpd_handle_t server;
    uint64_t epoch, connection;
    int fd;
} ts_ws_peer_t;
typedef struct ts_ws_message ts_ws_message_t;
typedef bool (*ts_ws_delivery_check_t)(uint64_t revision, uint64_t delivery);
typedef void (*ts_ws_delivery_done_t)(uint64_t revision, uint64_t delivery, esp_err_t result);
typedef void (*ts_ws_closed_t)(ts_ws_peer_t peer);
esp_err_t ts_ws_transport_start(httpd_handle_t server, ts_ws_closed_t closed);
esp_err_t ts_ws_transport_stop(httpd_handle_t server, uint32_t timeout_ms);
bool ts_ws_transport_in_context(void);
esp_err_t ts_ws_peer_open(httpd_req_t *req, ts_ws_peer_t *peer);
/* HTTPD owner only. Values, not bare fd, cross task boundaries. */
void ts_ws_peer_close(ts_ws_peer_t peer);
bool ts_ws_peer_get(httpd_handle_t server, int fd, ts_ws_peer_t *peer);
bool ts_ws_peer_equal(ts_ws_peer_t a, ts_ws_peer_t b);
unsigned ts_ws_transport_capacity(void);
ts_ws_message_t *ts_ws_message_json(const char *topic, const cJSON *data, int64_t timestamp);
ts_ws_message_t *ts_ws_message_text(const char *text, size_t len);
void ts_ws_message_release(ts_ws_message_t *message);
esp_err_t ts_ws_transport_submit(ts_ws_peer_t peer, ts_ws_message_t *message,
    uint64_t revision, uint64_t delivery, ts_ws_delivery_check_t check, ts_ws_delivery_done_t done);
/* Compatibility bridge for existing global/stream senders; never coalesces. */
esp_err_t ts_ws_transport_send(httpd_handle_t server, int fd, const httpd_ws_frame_t *frame);

void ts_ws_transport_stopped(httpd_handle_t server);
esp_err_t ts_ws_transport_broadcast(const httpd_ws_frame_t *frame);

void ts_ws_peer_log_level(ts_ws_peer_t peer, int level);
esp_err_t ts_ws_transport_log(const httpd_ws_frame_t *frame, int level);
unsigned ts_ws_message_capacity(void);

/* cJSON 1.7's AddItemReferenceToObject loses its newly allocated reference if
 * key duplication fails. Own that reference explicitly; keys here are static. */
static inline bool ts_ws_json_reference(cJSON *object, const char *key, const cJSON *data)
{
    if (!object || !data) return false;
    cJSON *ref = cJSON_CreateNull();
    if (!ref) return false;
    *ref = *data;
    ref->next = ref->prev = NULL;
    ref->string = NULL;
    ref->type = (ref->type & ~cJSON_StringIsConst) | cJSON_IsReference;
    if (cJSON_AddItemToObjectCS(object, key, ref)) return true;
    cJSON_Delete(ref);
    return false;
}

typedef struct {
    uint64_t queued, attempts, success, failed, stale, rejected;
    uint32_t bytes, bytes_high, jobs, jobs_high;
    int64_t max_send_us;
} ts_ws_transport_stats_t;
void ts_ws_transport_get_stats(ts_ws_transport_stats_t *stats);

/* Deterministic host barriers; compiled out in firmware. */
#ifndef TS_WS_TEST_POINT
#define TS_WS_TEST_POINT(name) ((void)0)
#endif

esp_err_t ts_ws_transport_quiesce(httpd_handle_t server, uint32_t timeout_ms);

void ts_ws_transport_flush(void);
bool ts_ws_transport_needs_flush(void);
void ts_ws_transport_cancel_topics(void);
