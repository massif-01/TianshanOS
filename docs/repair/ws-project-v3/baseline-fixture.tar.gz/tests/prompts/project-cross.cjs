const assert=require('node:assert/strict'),{spawn}=require('node:child_process'),readline=require('node:readline'),fs=require('node:fs');
const {harness}=require('./harness.cjs');
async function main(){
 const h=harness('en-US');await h.ready;h.load();await h.run('i18n.setLanguage("en-US")');
 h.run(`window.sent=[];window.lines=[];window.input=null;window.term=new WebTerminal('fixture');term.terminal={write:s=>lines.push(s),writeln:s=>lines.push(s),onData:f=>input=f};term.ws={readyState:1,send:s=>sent.push(JSON.parse(s))};term.setupInputHandler();`);
 const c=spawn('bash',['tests/ws_subscriptions/run_project_bridge.sh'],{cwd:require('node:path').resolve(__dirname,'../..'),env:process.env});
 let err='',pending;const records=[];c.stderr.on('data',b=>err+=b);let exit;const done=new Promise(r=>c.on('close',code=>{exit=code;r(code);if(pending){pending.reject(new Error(err||'C exited '+code));pending=null;}}));
 readline.createInterface({input:c.stdout}).on('line',line=>{let m;try{m=JSON.parse(line);}catch{throw Error(line);}records.push(m);if(m.frame && m.fd===1)h.ctx.term.handleMessage(m.frame);if('state'in m||m.finished){const p=pending;pending=null;p?.resolve(m);}});
 const step=msg=>new Promise((resolve,reject)=>{pending={resolve,reject};c.stdin.write(JSON.stringify(msg)+'\n');});
 await step({message:{type:'terminal_start'}});
 h.run(`term.startSshShell({host:'192.0.2.1',user:'fake',password:'fake',port:22})`);
 await step({message:h.ctx.sent.pop()});assert(h.ctx.term.sshMode);
 const before=h.ctx.lines.length;const state=await step({message:{type:'ssh_signal',signal:'TERM'}});
 const recovered=h.ctx.term.sshMode && !h.ctx.term.restoring && !h.ctx.lines.slice(before).some(x=>x==='tianshan> ');
 h.run(`input('x\\r')`);const next=h.ctx.sent.pop();
 await step({cmd:'finish'});await done;assert.equal(exit,0,err);
 const result={recovered,next,state,records};
 if(process.env.CROSS_OUTPUT)fs.writeFileSync(process.env.CROSS_OUTPUT,JSON.stringify(result,null,2));
 if(process.argv.includes('--baseline')){assert(!recovered && next.type!=='ssh_input');console.log('CONFIRMED H1: actual C request error leaves op OPEN but JS exits SSH and next input is not routed to SSH');return;}
 assert(recovered,'request failure changed active SSH mode/prompt/recovery');assert.equal(next.type,'ssh_input');
 console.log('PASS real C -> JSON -> production JS: recoverable error retains SSH route');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
