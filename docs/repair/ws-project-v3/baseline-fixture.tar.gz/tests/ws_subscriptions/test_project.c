#define OP_ADAPTER_NO_MAIN
#define PROJECT_REAL_DRIVER
#include "test_operation_adapter.c"
static void emit(httpd_ws_frame_t*f){printf("{\"frame\":%.*s,\"fd\":%d}\n",(int)f->len,f->payload,sent_fd);}
int main(void){
 cJSON_Hooks h={tracked_malloc,tracked_free};cJSON_InitHooks(&h);sent_hook=emit;setup();
 char line[4096];while(fgets(line,sizeof(line),stdin)){
  cJSON *j=cJSON_Parse(line);assert(j);const char *cmd=cJSON_GetStringValue(cJSON_GetObjectItem(j,"cmd"));
  if(cmd && !strcmp(cmd,"finish")){ssh_cleanup();if(shell_task.fn){shell_task.fn(shell_task.arg);shell_task.fn=NULL;}drive_all();cJSON_Delete(j);finish_all();assert(!driver_channels&&!driver_sessions&&!driver_sockets);puts("{\"finished\":true}");return 0;}
  if(cmd && !strcmp(cmd,"eof")){driver_eof=true;shell_task.fn(shell_task.arg);shell_task.fn=NULL;drive_all();}
  else if(cmd && !strcmp(cmd,"write_fail"))driver_write_fail=true;
  else if(cmd && !strcmp(cmd,"resize_reject"))driver_resize_reject=true;
  else if(cmd && !strcmp(cmd,"drain"))drive_all();
  else {
   int fd=1;cJSON *f=cJSON_GetObjectItem(j,"fd");if(f)fd=f->valueint;
   cJSON *msg=cJSON_GetObjectItem(j,"message");char *raw=cJSON_PrintUnformatted(msg);incoming=raw;reqs[fd].method=1;current=(void*)3;int ret=ws_handler(&reqs[fd]);current=(void*)1;incoming=NULL;cJSON_free(raw);assert(ret==0);drive_all();
   if(shell_task.fn && ((ssh_shell_context_t*)shell_task.arg)->disconnect_requested){shell_task.fn(shell_task.arg);shell_task.fn=NULL;drive_all();}
  }
  ts_ws_op_stats_t st;ts_ws_op_stats(TS_WS_OP_SHELL,&st);
  printf("{\"state\":%d,\"writes\":%d,\"live\":%u,\"channels\":%d,\"refs\":%u,\"preparing\":%u,\"unsettled\":%u}\n",st.phase,driver_writes,live_allocations,driver_channels,st.refs,st.preparing,st.unsettled);fflush(stdout);cJSON_Delete(j);
 }
 return 2;
}
